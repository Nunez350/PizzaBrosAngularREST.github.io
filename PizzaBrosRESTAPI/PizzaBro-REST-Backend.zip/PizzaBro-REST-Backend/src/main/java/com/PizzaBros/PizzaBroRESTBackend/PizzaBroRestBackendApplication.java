package com.PizzaBros.PizzaBroRESTBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzaBroRestBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PizzaBroRestBackendApplication.class, args);
	}

}
